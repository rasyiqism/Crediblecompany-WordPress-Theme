<?php
/**
 * Fallback template utama.
 * WordPress membutuhkan file ini sebagai template default.
 *
 * @package CredibleCompany
 */

get_header(); ?>

<!-- TEMPLATE: index.php -->

<main id="main" class="main-content">
    <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="entry-content">
                    <?php the_excerpt(); ?>
                </div>
            </article>
        <?php endwhile; ?>
    <?php else : ?>
        <p><?php esc_html_e( 'Tidak ada konten ditemukan.', 'crediblecompany' ); ?></p>
    <?php endif; ?>
</main>

<?php get_footer();
